const mongoose = require('mongoose');

const schema = new mongoose.Schema({
        title:{
                type: String,
		required: true,
          },
        value:{
                type: String,
		required: true,
          }
});

const Customer = mongoose.model('customer', schema);
module.exports = Customer;