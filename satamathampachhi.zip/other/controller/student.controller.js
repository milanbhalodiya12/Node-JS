const Student = require('.././model/Student.model')

exports.index = async (req, res)=>{
    try{ 
        const students = await Student.find();    
        res.status(201).json(students);

      } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

exports.show = async (req, res)=>{
    try{ 
        const student = await Student.find({"_id":req.params.id});    
        res.status(201).json(student);

      } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

exports.insert = async (req, res)=>{
    const student = await Student.create(req.body);
    res.send('insert student successfully');
}
exports.update = async (req, res)=>{
    const student = await Student.findByIdAndUpdate(req.body.id,req.body,{ new: true });
    res.send('update student successfully');
}
exports.delete = async (req, res)=>{
    const student = await Student.findByIdAndDelete(req.body.id);
    res.send('delete student successfully');
}