const Model = require('.././models/customer.model')

exports.index = async (req, res)=>{
    try{ 
        const customers = await Model.find();    
        res.status(201).json(customers);

      } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

exports.show = async (req, res)=>{
    try{ 
        const customer = await Model.find({"_id":req.params.id});    
        res.status(201).json(customer);

      } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

exports.store = async (req, res)=>{
    const customer = await Model.create(req.body);
    res.send('insert customer successfully');
}
    
exports.update = async (req, res)=>{
    const customer = await Model.findByIdAndUpdate(req.body.id,req.body,{ new: true });
    res.send('update customer successfully');
}

exports.destroy = async (req, res)=>{
    const customer = await Model.findByIdAndDelete(req.body.id);
    res.send('delete customer successfully');
}