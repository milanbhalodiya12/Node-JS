const{ DataTypes } = require('sequelize');
const{ sequelize, connectDB } = require('./../sequelizeConnection');

// Define the 'Customer' model
const Customer = sequelize.define('customers', {
        title: {
                 type: DataTypes.STRING,
                 allowNull: false
        },
        content: {
                type: DataTypes.STRING,
                allowNull: false
        }
    }, {
    tableName: 'customers', // Optional: Custom table name
        timestamps: false        // Disable timestamps like createdAt, updatedAt
    });
    
module.exports = Customer;
    