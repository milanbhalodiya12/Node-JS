const db = require('../connection.js');
exports.index = async (req, res)=>{
    try{ 
        let sql = 'SELECT * FROM customers';
        db.query(sql, (err, results) => {
            if (err) throw err;
            res.send(results);
        });
        //res.status(201).json(customers);
      } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

exports.show = async (req, res)=>{
    try{ 
        const customer = await Model.find({"_id":req.params.id});    
        res.status(201).json(customer);

      } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

exports.store = async (req, res)=>{
    try{ 

        let customer = { name: "Parth Katakiya", city: "Rajkot" };
        let sql = 'INSERT INTO customers SET ?';
        db.query(sql, customer, (err, result) => {
            if (err) throw err;
            res.send('Customer added successfully!');
        });
        //res.status(201).json(customers);
      } catch (error) {
        res.status(500).json({ error: error.message });
    }
    res.send('insert customer successfully');
}
    
exports.update = async (req, res)=>{
    const customer = await Model.findByIdAndUpdate(req.body.id,req.body,{ new: true });
    res.send('update customer successfully');
}

exports.destroy = async (req, res)=>{
    const customer = await Model.findByIdAndDelete(req.body.id);
    res.send('delete customer successfully');
}