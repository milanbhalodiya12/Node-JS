const express = require('express')
const router = express.Router()
const studentController = require('./../controller/student.controller')

router.get('/students',studentController.index)

router.get('/student/:id',studentController.show)

router.post('/student',studentController.insert)

router.put('/student',studentController.update)

router.delete('/student',studentController.delete)

module.exports = router