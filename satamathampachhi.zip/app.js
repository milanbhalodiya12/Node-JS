const express = require('express')
//const mongoose = require('mongoose');
const router = require('./routes/customer.route')
const cors = require('cors');


const app = express();
const port = 3000;
app.use(express.json());
app.use(cors());

// app.get('/api',(req, res)=>{
//     res.send('welcome to atmiya after satam atham');
// })
// mongoose.connect('mongodb+srv://prakashgujarati:8k1ulxNAaiYboIXU@cluster0.8cjw3hn.mongodb.net/mca',
//     {
//         useNewUrlParser: true,
//         useUnifiedTopology: true
//     }
// );

// Create a user (CREATE)
// app.get('/user/store', (req, res) => {
//     let customer = { name: "Atmiya University", city: "Rajkot" };
//     let sql = 'INSERT INTO customers SET ?';
//     db.query(sql, customer, (err, result) => {
//         if (err) throw err;
//         res.send('Customer added successfully!');
//     });
// });
app.use('/api',router)

app.listen(port,()=>{
    console.log(`test server listening on localhost:${port}`);
})