const mongoose = require('mongoose');



const studentSchema = new mongoose.Schema({
    "name":{
        "type":"string",
        "required":true
    },
    "enrollment":{
        "type":"number",
        "required":true
    }
})

const Student = mongoose.model('students', studentSchema);
  
  module.exports = Student;